w, a, s, d  -> move
e -> display inventory, close window
f or right-click -> activate object (indicated by yellow rectangle)
left click -> fire