Fight for Freedom, Concept Demo
By: Jesse Aldridge and Paul Gasca

Controls, Command Mode
----------------------
Click on a friendly ship to take control of it.

Controls, Local Mode
---------------------
W,A,S,D to move the ship
Click to shoot
Space to return to Command Mode


Known Bugs
--------------------
Currently controlled ship appears in center of view in local mode, when it should be at the bottom of the view.  This makes local mode somewhat unplayable.

After you return to command mode from local mode, you can still control the last ship you selected as though still in local mode.

Ships fly out of bounds sometimes and don't come back.

Explosions get drawn as squares rather than circles on some computers.

And there's a few other little bugs here and there...

These bugs are all minor and will be fixed in the near future.