
Instructions for "FFF_Shooting"
---------------------------------

W,A,S,D to move the ship
Click to shoot


Additional instructions for "FFF_Space_Battle"
-----------------------------------------------

Click a ship to select it.
Press space to return to command mode.